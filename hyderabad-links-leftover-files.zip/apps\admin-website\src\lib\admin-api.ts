import { redirect } from "next/navigation";
import { readTokens } from "./session";
import type { SessionTokens } from "./session-cookies";

// Server-side only. The browser never calls the API: server components and server actions do,
// attaching the admin's token from the httpOnly cookie.
const API_BASE_URL = process.env.API_BASE_URL ?? "http://localhost:5080";

export type AdminProfile = {
  id: number;
  email: string;
  displayName: string;
  roles: string[];
  /** What this admin may do. The API checks every permission again; this only decides what to draw. */
  permissions: string[];
};

export type QueueItem = {
  id: number;
  name: string;
  status: string;
  categoryName: string | null;
  localityName: string;
  addressLine: string | null;
  phonePrimary: string;
  createdAt: string;
  updatedAt: string;
};

export type QueuePage = {
  items: QueueItem[];
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
};

export type AdminListing = {
  id: number;
  slug: string;
  name: string;
  status: string;
  description: string | null;
  addressLine: string | null;
  pincode: string | null;
  phonePrimary: string;
  phoneWhatsapp: string | null;
  email: string | null;
  websiteUrl: string | null;
  latitude: number;
  longitude: number;
  citySlug: string;
  localitySlug: string;
  localityName: string;
  categorySlug: string | null;
  categoryName: string | null;
  submittedByPhone: string | null;
  createdAt: string;
  updatedAt: string;
  publishedAt: string | null;
  reviewNote: string | null;
  reviewedAt: string | null;
  reviewedBy: string | null;
  url: string | null;
};

/** Permission codes used by these screens. They must match BusinessDirectory.Api.Auth.AdminPermissions. */
export const PERMISSION_VIEW = "listings.view";
export const PERMISSION_REVIEW = "listings.review";
export const PERMISSION_CREATE = "listings.create";
export const PERMISSION_EDIT = "listings.edit";
/** The seeded description of this one already reads "Handle abuse reports and reviews". */
export const PERMISSION_REPORTS = "reports.handle";

export type ApiFailure = { ok: false; status: number; message: string; fieldErrors: Record<string, string> };
export type ApiResult<T> = { ok: true; data: T } | ApiFailure;

async function toFailure(response: Response): Promise<ApiFailure> {
  let message = "Something went wrong. Please try again.";
  const fieldErrors: Record<string, string> = {};
  try {
    const body = (await response.json()) as { detail?: unknown; errors?: Record<string, unknown> };
    if (body.errors && typeof body.errors === "object") {
      for (const [field, messages] of Object.entries(body.errors)) {
        if (Array.isArray(messages) && typeof messages[0] === "string") fieldErrors[field] = messages[0];
      }
      message = Object.values(fieldErrors)[0] ?? "Please fix the fields marked below.";
    } else if (typeof body.detail === "string") {
      message = body.detail;
    }
  } catch {
    // Not JSON: keep the generic message.
  }
  return { ok: false, status: response.status, message, fieldErrors };
}

async function send<T>(path: string, init: RequestInit, accessToken?: string): Promise<ApiResult<T>> {
  const headers = new Headers(init.headers);
  headers.set("Accept", "application/json");
  if (init.body) headers.set("Content-Type", "application/json");
  if (accessToken) headers.set("Authorization", `Bearer ${accessToken}`);
  let response: Response;
  try {
    response = await fetch(`${API_BASE_URL}${path}`, { ...init, headers, cache: "no-store" });
  } catch {
    return { ok: false, status: 0, message: "We could not reach the API. Please try again in a moment.", fieldErrors: {} };
  }
  if (!response.ok) return toFailure(response);
  if (response.status === 204) return { ok: true, data: undefined as T };
  return { ok: true, data: (await response.json()) as T };
}

/** Calls an admin endpoint with the signed-in admin's token. No token, or a rejected token, means sign in again. */
async function authed<T>(path: string, init: RequestInit = {}): Promise<ApiResult<T>> {
  const { access } = await readTokens();
  if (!access) redirect("/login/reset");
  const result = await send<T>(path, init, access);
  if (!result.ok && result.status === 401) redirect("/login/reset");
  return result;
}

const json = (value: unknown): string => JSON.stringify(value);

// ---- sign in (no token needed)
/**
 * A correct password no longer returns a session. MFA is mandatory, so it returns a short-lived
 * token for the second step: `stage` is "mfa" when the admin already has an authenticator and
 * "enroll" when they must set one up, which is every admin's first sign-in.
 */
export type MfaRequired = { stage: "mfa" | "enroll"; mfaToken: string; expiresInSeconds: number };

/** `secret` is Base32, for typing in when a QR code cannot be scanned. */
export type Enrollment = { secret: string; otpauthUri: string };

/** Recovery codes come back exactly once, at enrollment, and can never be retrieved again. */
export type Enrolled = SessionTokens & { recoveryCodes: string[] };

export const adminLogin = (email: string, password: string) =>
  send<MfaRequired>("/api/v1/auth/admin/login", { method: "POST", body: json({ email, password }) });

// The second step. Each of these is reachable only with the token the password step returned,
// because the API gives that token a different audience from a real admin token.
export const startEnrollment = (mfaToken: string) =>
  send<Enrollment>("/api/v1/auth/admin/mfa/enroll/start", { method: "POST" }, mfaToken);

export const confirmEnrollment = (mfaToken: string, code: string) =>
  send<Enrolled>("/api/v1/auth/admin/mfa/enroll/confirm", { method: "POST", body: json({ code }) }, mfaToken);

export const verifyMfa = (mfaToken: string, input: { code?: string; recoveryCode?: string }) =>
  send<SessionTokens>("/api/v1/auth/admin/mfa/verify", { method: "POST", body: json(input) }, mfaToken);

export const adminLogout = (refreshToken: string) =>
  send<void>("/api/v1/auth/admin/logout", { method: "POST", body: json({ refreshToken }) });

// ---- signed-in admin
export const getAdminProfile = () => authed<AdminProfile>("/api/v1/admin/me");

export const getQueue = (status: string, page: number) =>
  authed<QueuePage>(`/api/v1/admin/listings?status=${encodeURIComponent(status)}&page=${page}`);

export const getListing = (id: number) => authed<AdminListing>(`/api/v1/admin/listings/${id}`);

export const approveListing = (id: number) =>
  authed<AdminListing>(`/api/v1/admin/listings/${id}/approve`, { method: "POST" });

export const rejectListing = (id: number, reason: string) =>
  authed<AdminListing>(`/api/v1/admin/listings/${id}/reject`, { method: "POST", body: json({ reason }) });

/** The statuses an admin can filter by, in the order the tabs appear. Mirrors ModerationQueueQuery. */
/** One review waiting on a moderator. The reviewer is identified by phone, which is not public. */
export type ModerationReview = {
  id: number;
  listingId: number;
  listingName: string;
  rating: number;
  body: string;
  reviewerPhone: string;
  createdAt: string;
};

export type ModerationReviewPage = {
  items: ModerationReview[];
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
};

export const REVIEW_STATUSES = ["pending", "approved", "rejected"] as const;
export type ReviewStatus = (typeof REVIEW_STATUSES)[number];

export const getReviewQueue = (status: string, page: number) =>
  authed<ModerationReviewPage>(
    '/api/v1/admin/reviews?status=' + encodeURIComponent(status) + '&page=' + page,
  );

export const approveReview = (id: number) =>
  authed<void>('/api/v1/admin/reviews/' + id + '/approve', {
    method: 'POST',
    body: JSON.stringify({ note: null }),
  });

/** The note is what the reviewer reads, so a rejection should always carry one. */
export const rejectReview = (id: number, note: string) =>
  authed<void>('/api/v1/admin/reviews/' + id + '/reject', {
    method: 'POST',
    body: JSON.stringify({ note: note.trim() === '' ? null : note.trim() }),
  });

/** Takes a live listing off the public site. The reason is shown to the owner. */
export const suspendListing = (id: number, reason: string) =>
  authed<AdminListing>('/api/v1/admin/listings/' + id + '/suspend', {
    method: 'POST',
    body: JSON.stringify({ reason }),
  });

export const reinstateListing = (id: number) =>
  authed<AdminListing>('/api/v1/admin/listings/' + id + '/reinstate', { method: 'POST' });

/** One abuse report. `subjectName` is the business it is about, whichever kind of subject it is. */
export type AbuseReport = {
  id: number;
  subjectType: "listing" | "review";
  subjectId: number;
  subjectName: string;
  reviewBody: string | null;
  reason: string;
  details: string | null;
  status: string;
  resolutionNote: string | null;
  createdAt: string;
};

export type AbuseReportPage = {
  items: AbuseReport[];
  page: number;
  pageSize: number;
  total: number;
  totalPages: number;
};

export const REPORT_STATUSES = ["open", "actioned", "dismissed"] as const;
export type ReportStatus = (typeof REPORT_STATUSES)[number];

/** The API's reason codes, in plain words for the queue. */
export const REPORT_REASON_LABELS: Record<string, string> = {
  not_a_real_business: "Not a real business",
  wrong_details: "The details are wrong",
  closed_down: "Closed down",
  offensive_content: "Offensive content",
  spam: "Spam",
  other: "Something else",
};

export const getReportQueue = (status: string, page: number) =>
  authed<AbuseReportPage>(
    '/api/v1/admin/reports?status=' + encodeURIComponent(status) + '&page=' + page,
  );

/** Records that something was done about the subject. Acting on it is a separate, audited action. */
export const actionReport = (id: number, note: string) =>
  authed<void>('/api/v1/admin/reports/' + id + '/action', {
    method: 'POST',
    body: JSON.stringify({ note: note.trim() === '' ? null : note.trim() }),
  });

export const dismissReport = (id: number, note: string) =>
  authed<void>('/api/v1/admin/reports/' + id + '/dismiss', {
    method: 'POST',
    body: JSON.stringify({ note: note.trim() === '' ? null : note.trim() }),
  });

export const QUEUE_STATUSES = ["pending_review", "active", "rejected", "draft", "suspended"] as const;

export function describeStatus(status: string): { label: string; tone: "grey" | "amber" | "green" | "red" } {
  switch (status) {
    case "pending_review":
      return { label: "Waiting for review", tone: "amber" };
    case "active":
      return { label: "Live", tone: "green" };
    case "rejected":
      return { label: "Rejected", tone: "red" };
    case "draft":
      return { label: "Draft", tone: "grey" };
    case "suspended":
      return { label: "Suspended", tone: "red" };
    default:
      return { label: status, tone: "grey" };
  }
}

/** Short, unambiguous date and time for a reviewer. Rendered on the server, so the zone is the server's. */
export function formatWhen(value: string | null): string {
  if (!value) return "—";
  return new Date(value).toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

// ---- reference data for the listing form (public endpoints, no token needed)
export type SubCategory = { slug: string; name: string };
export type Category = { slug: string; name: string; children: SubCategory[] };
export type Locality = { slug: string; name: string };

/** The city the directory covers today. Localities are listed per city. */
export const DEFAULT_CITY = "hyderabad";

async function getPublic<T>(path: string, fallback: T): Promise<T> {
  const result = await send<T>(path, { method: "GET" });
  return result.ok ? result.data : fallback;
}

export const getCategories = () => getPublic<Category[]>("/api/v1/public/categories", []);
export const getLocalities = () => getPublic<Locality[]>(`/api/v1/public/cities/${DEFAULT_CITY}/localities`, []);

// ---- creating and editing a listing as an admin
/** What the listing form sends. The API trims and validates every field again. */
export type ListingFormInput = {
  name: string;
  description: string;
  categorySlug: string;
  localitySlug?: string;
  addressLine: string;
  pincode: string;
  phonePrimary: string;
  phoneWhatsapp: string;
  websiteUrl: string;
};

const orNull = (value: string | undefined) => (value && value.trim() !== "" ? value.trim() : null);

function toPayload(input: ListingFormInput) {
  return {
    name: orNull(input.name),
    description: orNull(input.description),
    categorySlug: orNull(input.categorySlug),
    localitySlug: orNull(input.localitySlug),
    addressLine: orNull(input.addressLine),
    pincode: orNull(input.pincode),
    phonePrimary: orNull(input.phonePrimary),
    phoneWhatsapp: orNull(input.phoneWhatsapp),
    websiteUrl: orNull(input.websiteUrl),
  };
}

export const createListing = (input: ListingFormInput) =>
  authed<AdminListing>("/api/v1/admin/listings", { method: "POST", body: json(toPayload(input)) });

export const updateListing = (id: number, input: ListingFormInput) =>
  authed<AdminListing>(`/api/v1/admin/listings/${id}`, {
    method: "PUT",
    body: json(toPayload({ ...input, localitySlug: undefined })),
  });
