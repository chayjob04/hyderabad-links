﻿SET XACT_ABORT ON;

BEGIN TRANSACTION;

-- 1. Remove legacy plan assignments before retiring the old plans.
-- Existing listings remain intact and become free listings.
UPDATE listings
SET plan_slug = 'free',
    updated_at = SYSDATETIMEOFFSET()
WHERE plan_slug IS NULL
   OR plan_slug NOT IN ('free', 'verified');

-- 2. Keep Free and create/update the single paid plan.
UPDATE plans
SET name = 'Free',
    price_paise = 0,
    photo_limit = 0,
    video_limit = 0,
    logo_limit = 0,
    grants_verified_badge = 0,
    media_limits_confirmed = 1,
    sort_order = 0,
    updated_at = SYSDATETIMEOFFSET()
WHERE slug = 'free';

IF NOT EXISTS (SELECT 1 FROM plans WHERE slug = 'free')
BEGIN
    INSERT INTO plans
        (slug, name, price_paise, photo_limit, video_limit, logo_limit,
         grants_verified_badge, media_limits_confirmed, sort_order)
    VALUES
        ('free', 'Free', 0, 0, 0, 0, 0, 1, 0);
END;

IF EXISTS (SELECT 1 FROM plans WHERE slug = 'verified')
BEGIN
    UPDATE plans
    SET name = 'Verified',
        price_paise = 39900,
        photo_limit = 10,
        video_limit = 3,
        logo_limit = 1,
        grants_verified_badge = 1,
        media_limits_confirmed = 1,
        sort_order = 1,
        updated_at = SYSDATETIMEOFFSET()
    WHERE slug = 'verified';
END
ELSE
BEGIN
    INSERT INTO plans
        (slug, name, price_paise, photo_limit, video_limit, logo_limit,
         grants_verified_badge, media_limits_confirmed, sort_order)
    VALUES
        ('verified', 'Verified', 39900, 10, 3, 1, 1, 1, 1);
END;

-- 3. Retire the old paid plans.
-- Existing listings were moved to Free above.
DELETE FROM plans
WHERE slug NOT IN ('free', 'verified');

-- 4. Store paid subscription periods per listing.
IF OBJECT_ID('subscriptions', 'U') IS NULL
BEGIN
    CREATE TABLE subscriptions (
        id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        listing_id BIGINT NOT NULL,
        plan_slug NVARCHAR(40) NOT NULL,
        status NVARCHAR(20) NOT NULL,
        starts_at DATETIMEOFFSET(3) NOT NULL,
        expires_at DATETIMEOFFSET(3) NOT NULL,
        created_at DATETIMEOFFSET(3) NOT NULL
            CONSTRAINT DF_subscriptions_created_at DEFAULT SYSDATETIMEOFFSET(),
        updated_at DATETIMEOFFSET(3) NOT NULL
            CONSTRAINT DF_subscriptions_updated_at DEFAULT SYSDATETIMEOFFSET(),

        CONSTRAINT FK_subscriptions_listing
            FOREIGN KEY (listing_id) REFERENCES listings(id),
        CONSTRAINT FK_subscriptions_plan
            FOREIGN KEY (plan_slug) REFERENCES plans(slug),
        CONSTRAINT CK_subscriptions_status
            CHECK (status IN ('pending', 'active', 'expired', 'cancelled')),
        CONSTRAINT CK_subscriptions_period
            CHECK (expires_at > starts_at)
    );

    CREATE INDEX IX_subscriptions_listing_period
        ON subscriptions(listing_id, status, expires_at);
END;

-- 5. Record payment attempts and verified payment references.
IF OBJECT_ID('subscription_payments', 'U') IS NULL
BEGIN
    CREATE TABLE subscription_payments (
        id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        listing_id BIGINT NOT NULL,
        subscription_id BIGINT NULL,
        provider NVARCHAR(30) NOT NULL
            CONSTRAINT DF_subscription_payments_provider DEFAULT 'razorpay',
        provider_order_id NVARCHAR(100) NULL,
        provider_payment_id NVARCHAR(100) NULL,
        amount_paise BIGINT NOT NULL,
        currency CHAR(3) NOT NULL
            CONSTRAINT DF_subscription_payments_currency DEFAULT 'INR',
        status NVARCHAR(20) NOT NULL,
        signature_verified_at DATETIMEOFFSET(3) NULL,
        paid_at DATETIMEOFFSET(3) NULL,
        webhook_event_id NVARCHAR(150) NULL,
        created_at DATETIMEOFFSET(3) NOT NULL
            CONSTRAINT DF_subscription_payments_created_at DEFAULT SYSDATETIMEOFFSET(),
        updated_at DATETIMEOFFSET(3) NOT NULL
            CONSTRAINT DF_subscription_payments_updated_at DEFAULT SYSDATETIMEOFFSET(),

        CONSTRAINT FK_subscription_payments_listing
            FOREIGN KEY (listing_id) REFERENCES listings(id),
        CONSTRAINT FK_subscription_payments_subscription
            FOREIGN KEY (subscription_id) REFERENCES subscriptions(id),
        CONSTRAINT CK_subscription_payments_amount
            CHECK (amount_paise > 0),
        CONSTRAINT CK_subscription_payments_status
            CHECK (status IN ('created', 'pending', 'paid', 'failed', 'refunded'))
    );

    CREATE UNIQUE INDEX UX_subscription_payments_order
        ON subscription_payments(provider, provider_order_id)
        WHERE provider_order_id IS NOT NULL;

    CREATE UNIQUE INDEX UX_subscription_payments_payment
        ON subscription_payments(provider, provider_payment_id)
        WHERE provider_payment_id IS NOT NULL;

    CREATE UNIQUE INDEX UX_subscription_payments_webhook
        ON subscription_payments(provider, webhook_event_id)
        WHERE webhook_event_id IS NOT NULL;
END;

-- 6. Store up to five website/social links per listing.
IF OBJECT_ID('listing_links', 'U') IS NULL
BEGIN
    CREATE TABLE listing_links (
        id BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
        listing_id BIGINT NOT NULL,
        link_type NVARCHAR(20) NOT NULL,
        label NVARCHAR(80) NOT NULL,
        url NVARCHAR(1000) NOT NULL,
        sort_order INT NOT NULL
            CONSTRAINT DF_listing_links_sort_order DEFAULT 0,
        created_at DATETIMEOFFSET(3) NOT NULL
            CONSTRAINT DF_listing_links_created_at DEFAULT SYSDATETIMEOFFSET(),
        updated_at DATETIMEOFFSET(3) NOT NULL
            CONSTRAINT DF_listing_links_updated_at DEFAULT SYSDATETIMEOFFSET(),

        CONSTRAINT FK_listing_links_listing
            FOREIGN KEY (listing_id) REFERENCES listings(id) ON DELETE CASCADE,
        CONSTRAINT CK_listing_links_type
            CHECK (link_type IN
                ('website', 'instagram', 'facebook', 'youtube',
                 'linkedin', 'x', 'other')),
        CONSTRAINT CK_listing_links_sort
            CHECK (sort_order BETWEEN 0 AND 4)
    );

    CREATE INDEX IX_listing_links_listing
        ON listing_links(listing_id, sort_order, id);
END;

COMMIT TRANSACTION;
GO
